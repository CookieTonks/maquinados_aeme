<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Maquinados AEME - Dashboard</title>

    <!-- Custom fonts for this template-->
    <link href="template/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.css">
    <!-- Custom styles for this template-->
    <link href="template/css/sb-admin-2.min.css" rel="stylesheet">


</head>

<body id="page-top">


    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="http://maquinadosaeme.com/">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-fw fa-cog"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Maquinados AEME </div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="{{route('home')}}">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Menu
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <hr class="sidebar-divider">

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>Almacen</span>
                </a>
                <div id="collapseOne" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header"> Barra de tareas </h6>
                        <a class="collapse-item" href="{{ route('home_recepcion_herramienta') }}">Entrada de herramienta</a>
                        <a class="collapse-item" href="{{ route('home_inventario_folio') }}">Salida de herramienta</a>
                        <a class="collapse-item" href="{{ route('home_recepcion_material') }}">Entrada de material</a>
                        <a class="collapse-item" href="{{ route('home_salida_material') }}">Salida de material</a>
                        <a class="collapse-item" href="{{ route('home_inventario') }}">Inventario de almacen</a>
                        <a class="collapse-item" href="{{ route('home_material_historico') }}">Material historicos</a>
                    </div>
                </div>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="{{route('dashboard_material_cliente')}}">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Cliente</span></a>
            </li>
            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>


            <!-- Sidebar Message
      <div class="sidebar-card d-none d-lg-flex">
      <img class="sidebar-card-illustration mb-2" src="img/undraw_rocket.svg" alt="...">
                       <p class="text-center mb-2"><strong>Maquinados AEME</strong></p>
                       <a class="btn btn-success btn-sm" href="https://startbootstrap.com/theme/sb-admin-pro">Upgrade to Pro!</a>
                     </div>
                      -->

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"> {{ Auth::user()->name }}</span>
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                                <form method="POST" action="{{ route('logout') }}">
                                    @csrf
                                    <a class="dropdown-item" data-toggle="modal" href="href=" route( 'logout' ) " onclick=" event.preventDefault(); this.closest( 'form' ).submit(); ""> <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i> {{ __('Log out') }}
                                </form>
                                </a>
                            </div>
                        </li>
                    </ul>
                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="card-body">
                    @if (session('mensaje'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        {{session('mensaje')}}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <script type="text/javascript">
                            $('.alert').alert()
                        </script>
                    </div>
                    @endif
                    <form action="" method="post" enctype="multipart/form-data">
                        @csrf
                    </form>
                    <table id="dtBasicExample" class="table table-striped table-bordered table-lg" cellspacing="0" width="100%">
                        <thead>
                            <tr style="text-align: center;">
                                <th class="th-sm">Partida</th>
                                <th class="th-sm">Requisicion</th>
                                <th class="th-sm">OC</th>
                                <th class="th-sm">OT</th>
                                <th class="th-sm">Descripcion</th>
                                <th class="th-sm">Material</th>
                                <th class="th-sm">Fecha</th>
                                <th class="th-sm">Cantidad</th>
                                <th class="th-sm">Unidad</th>
                                <th class="th-sm">Proveedor</th>
                                <th class="th-sm">Precio Unitario</th>
                                <th class="th-sm">Certificado</th>
                                <th class="th-sm">Fecha de recepcion</th>
                                <th class="th-sm">Fecha de entrega</th>

                            </tr>
                        </thead>
                        <tbody style="text-align: center;">
                            @foreach($materiales as $material)
                            @if($material->partida_recibida==1 && $material->salida_partida==1)
                            <tr class="table-success">
                                <td>{{$material->partida}}</td>
                                <td>{{$material->requisicion}}</td>
                                <td>
                                    <a href="../storage/app/public/Ordenes_de_compras/{{$material->orden_compra}}.pdf">{{$material->orden_compra}}</a>
                                </td>
                                <td>{{$material->ot}}</td>
                                <td>{{$material->descripcion}}</td>
                                <td>{{$material->material_partida}}</td>
                                <td>{{$material->created_at}}</td>
                                <td>{{$material->cantidad}}</td>
                                <td>{{$material->unidad}}</td>
                                <td>{{$material->proveedor}}</td>
                                <td>{{$material->precio_unitario}}</td>
                                @if($material->certificado_cargado=='0')
                                <td style="background:#ed1858;">CERTIFICADO PENDIENTE</td>
                                @else
                                <td>
                                    <a href="../storage/certificado_material/{{$material->partida}}.pdf">CERTIFICADO {{$material->partida}}</a>
                                </td>
                                @endif
                                <td>{{$material->fecha_recibida}}</td>
                                <td>{{$material->fecha_entrega}}</td>
                            </tr>
                            @elseif($material->partida_recibida==1 && $material->salida_partida==0)
                            <tr class="table-warning">
                                <td>{{$material->partida}}</td>
                                <td>{{$material->requisicion}}</td>
                                <td>
                                    <a href="../storage/app/public/Ordenes_de_compras/{{$material->orden_compra}}.pdf">{{$material->orden_compra}}</a>
                                </td>
                                <td>{{$material->ot}}</td>
                                <td>{{$material->descripcion}}</td>
                                <td>{{$material->material_partida}}</td>
                                <td>{{$material->created_at}}</td>
                                <td>{{$material->cantidad}}</td>
                                <td>{{$material->unidad}}</td>
                                <td>{{$material->proveedor}}</td>
                                <td>{{$material->precio_unitario}}</td>
                                @if($material->certificado_cargado=='0')
                                <td style="background:#ed1858;">CERTIFICADO PENDIENTE</td>
                                @else
                                <td>
                                    <a href="../storage/certificado_material/{{$material->partida}}.pdf">CERTIFICADO {{$material->partida}}</a>
                                </td>
                                @endif
                                <td>{{$material->fecha_recibida}}</td>
                                <td>{{$material->fecha_entrega}}</td>
                            </tr>
                            @endif
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <!-- End of Main Content -->

                <!-- Footer -->
                <footer class="sticky-footer bg-white">
                    <div class="container my-auto">
                        <div class="copyright text-center my-auto">
                            <span>Copyright &copy; Maquinados AEME S.A de C.V 2021</span>
                            <!-- Development by Miriam Dominguez -->
                        </div>
                    </div>
                </footer>
                <!-- End of Footer -->
            </div>
            <!-- End of Content Wrapper -->
        </div>
        <!-- End of Page Wrapper -->

        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>

        <div class="modal fade" id="entrada_material" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="{{route('almacen_alta_material_registro')}}" method="post">
                            @csrf
                            <div class="form-row">
                                <div class="col-md-12 mb-3">
                                    <h2>ENTRADA MATERIAL AEME</h2>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="col-md-12 mb-3">
                                    <label>OT</label>
                                    <input id="entrada_material_ot" type="text" class="form-control" name="entrada_material_ot" readonly>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="col-md-12 mb-3">
                                    <label>DESCRIPCION</label>
                                    <input id="entrada_material_descripcion" type="text" class="form-control" name="entrada_material_descripcion" readonly>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="col-md-12 mb-3">
                                    <label>PARTIDA</label>
                                    <input id="entrada_material_partida" type="text" class="form-control" name="entrada_material_partida" readonly>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="col-md-12 mb-3">
                                    <label>FACTURA - SALIDA MATERIAL</label>
                                    <input id="entrada_material_factura" type="text" class="form-control" name="entrada_material_factura">
                                </div>
                            </div>
                            <button class="btn btn-success btn-block" type="submit">REGISTRAR</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <script src="../template/vendor/jquery/jquery.min.js"></script>
        <script src="../template/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Core plugin JavaScript-->
        <script src="../template/vendor/jquery-easing/jquery.easing.min.js"></script>

        <!-- Custom scripts for all pages-->
        <script src="../template/js/sb-admin-2.min.js"></script>

        <!-- MDB -->
        <script type="text/javascript" src="js/mdb.min.js"></script>
        <!-- Custom scripts -->
        <script src="http://code.jquery.com/jquery-2.0.3.min.js"></script>
        <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js"></script>
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
        <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js"></script>
        <script src="../template/js/sb-admin-2.min.js"></script>
        <script>
            $(document).ready(function() {
                $('#dtBasicExample').DataTable();
            });
        </script>

</body>

</html>